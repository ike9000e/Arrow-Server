#include "nproc_helpers.h"
//#include <cctype>
#include <cstring>
//#include <cstdlib>
//#include <string.h>
#include <stdio.h>
#include <stdlib.h>

#ifdef WIN32 //{
	#include <windows.h> //Sleep()
#else  //__GNUC__
	#include <unistd.h> //usleep()
#endif //}

namespace nproc{
;
std::string
nproc_CreateSimpleHttpRqHeader( const char* szHost, const char* szRq,
			const char* szOffsetInBytes, const char* method )
{
	// "GET %1 HTTP/1.1\r\n"
	std::string rq(std::string(method&&*method?method:"GET")+" "+std::string(szRq)+std::string(" HTTP/1.1\r\n"));
	// "Host: %1\r\n"
	std::string hdr1(std::string("Host: ")+std::string(szHost)+std::string("\r\n"));
	std::string hdrs;
	{
		hdrs += "Accept: \x22\x2F\x22\r\n"; //0x2A = asterisk ('*'), 0x2F = slash.
		hdrs += "Pragma: no-cache\r\n";
		hdrs += "Cache-Control: no-cache\r\n";
		hdrs += "Connection: close\r\n";
		if( szOffsetInBytes && *szOffsetInBytes ){
			if( atoi(szOffsetInBytes) ){
				// "Range: bytes=%1-\r\n"
				hdrs += std::string("Range: bytes=")+std::string(szOffsetInBytes)+std::string("-\r\n");
			}
		}
	//	if(lsExtraHeaders){
	//		std::vector<std::string>::const_iterator a;
	//		for( a = lsExtraHeaders->begin(); a != lsExtraHeaders->end(); ++a ){
	//			//hdrs += hf_rtrim_stdstring( a->c_str(), "\r\n" ).c_str();
	//		}
	//	}
		hdrs += "\r\n";
	}
	std::string str = rq + hdr1 + hdrs;
	return str;
}
std::vector<uint8_t> nproc_StrToBytes( const char* in )
{
	std::vector<uint8_t> out;
	for(; *in; in++ )
		out.push_back( (uint8_t) *in );
	return out;
}
/// Converts data to printable string.
/// flags - f.e. NPROC_EDTS_ShowCrLfAsStrs.
std::string nproc_dataToString( const void* data2, size_t size, size_t flags )
{
	const unsigned char* data = (const unsigned char*)data2;
	std::string z;
	size_t i; unsigned char c;
	for( i=0; i<size; i++ ){
		c = data[i];
		if( c == '\r' || c == '\n' ){
			if( flags & NPROC_EDTS_ShowCrLfAsStrs ){
				z += c == '\r' ? "\\r" : "\\n";
				if( flags & NPROC_EDTS_LfFollowsVisibleLf && c == '\n' ){
					z += "\n";
				}
			}else{
				z += c;
			}
		}else if( isprint( c ) ){
			z += data[i];
		}else{
			z += ".";
		}
	}
	return z;
}
/// Decodes HTTP Range header returning 'pos' and 'end' values as multibyte strings.
/// szRangeHdr examples:
/// "Range: bytes=200-300\r\n"
/// "Range: bytes=10001-\r\n"
/// "bytes=10001-\r\n"
/// "=10001-\r\n"
bool nproc_decodeHttpRangeHeader( const char* szRangeHdr, std::string* rangePos, std::pair<bool,std::string>* rangeEnd )
{
	const char* sz, *sz2 = szRangeHdr, *szDec = "0123456789";
	if(rangePos)
		*rangePos = "";
	if(rangeEnd)
		*rangeEnd = std::pair<bool,std::string>(0,"");
	if( ( sz = strchr(sz2,'=') ) ){
		size_t i;
		for(sz++,i=0; i<4 && strchr(" ",*sz); sz++, i++ );
		if( strchr(szDec,*sz) ){
			sz2 = sz;
			for(i=0; i<128 && strchr(szDec,*sz); sz++, i++ );
			std::string strRangePos2( sz2, sz - sz2 );
			for(i=0; i<4 && strchr(" ",*sz); sz++, i++ );
			if( *sz == '-' ){
				sz++;
				for(i=0; i<4 && strchr(" ",*sz); sz++, i++ );
				std::pair<bool,std::string> rangeEnd2(0,"");
				if( strchr(szDec,*sz) ){
					rangeEnd2.first = 1;
					sz2 = sz;
					for(i=0; i<128 && strchr(szDec,*sz); sz++, i++ );
					rangeEnd2.second.assign( sz2, sz - sz2 );
				}
				if(rangePos)
					*rangePos = strRangePos2;
				if(rangeEnd)
					*rangeEnd = rangeEnd2;
				return 1;
			}
		}
	}
	return 0;
}

/// Sleep current thread for given miliseconds time.
/// Value 1000 = 1 second.
void nproc_Sleep( uint32_t uMilisecs )
{
	#ifdef WIN32
		Sleep( uMilisecs );
	#else
		usleep( uMilisecs * 1000 );
	#endif
}
/**
	Creates simple HTTP OK server response header given optional body.
*/
std::vector<uint8_t> nproc_CreateSimpleHTTPOKResponse( const char* szBody )
{
	char bfr[1024];
	sprintf( bfr,
		"HTTP/1.1 200 OK\r\n"
		"Content-Length: %d\r\n"	// <----- %u
		"Content-Type: text/html;charset=UTF-8\r\n"
		"Accept-Ranges: bytes\r\n"
		"Connection: close\r\n"
		"\r\n", (int)strlen(szBody) );
	std::string strResp = bfr;
	strResp += szBody;
	return nproc_StrToBytes( strResp.c_str() );
}
/**
	Creates simple HTTP Not Found server header given optional body and headers.
	\param szBody     - optional body.
	\param szCustHdrs - Optional, vustom HTTP headers, if any. each must be terminated
	                    by CrLf (\r\n). Last custom header must not be terminated by extra CrLf.
*/
std::vector<uint8_t>
nproc_CreateSimpleHTTPNotFoundResponse( const char* szBody, const char* szCustHdrs )
{
	char bfr[1024];
	sprintf( bfr,
		"HTTP/1.1 404 Not Found\r\n"
		"Connection: close\r\n"
		"Content-Length: %d\r\n"
		"Content-Type: text/html;charset=UTF-8\r\n"
		"%s"
		"\r\n", (int)strlen(szBody), szCustHdrs );
	std::string strResp = bfr;
	strResp += szBody;
	return nproc_StrToBytes( strResp.c_str() );
}

} // end namespace nproc
