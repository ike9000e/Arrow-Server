#include "NprocServer.h"
//#include <cctype>
#include <cstring>
//#include <cstdlib>
//#include <string.h>
#include <stdio.h>
#include <algorithm>

#ifdef WIN32 //{
	#include <windows.h>
	#include <stdlib.h>
#else  //__GNUC__
	#include <unistd.h>
	#include <sys/ioctl.h>
	#include <sys/socket.h>
	#include <arpa/inet.h>
	#include <netdb.h>
#endif //}

//template<typename... Types>
//void fnc( Types... xs )
//{
//}

// close() == closesocket() on MS-WINDOWS
// ioctl() == ioctlsocket() on MS-Windows
#ifdef WIN32
	#define close closesocket
	#define ioctl ioctlsocket
	typedef int socklen_t;
#endif //WIN32

// err:module:import_dll Library libintl-8.dll (which is needed by L"Z:\\media\\bob\\BAQ\\drive\\apps_b\\programming\\compilers\\mingw\\mingw_4x9x2_win32\\mingw32\\bin\\as.exe") not found

namespace nproc {

/// Default interface implementaion for simple string printing using printf().
class CSrvPrintfHndlrDflt : public NprocISrvPrintfHandler { public:
	virtual void NprocSrvPrintf( const char* inp, size_t uVerbLevel ){
		printf("%s", inp );
	}
} ;

static CSrvPrintfHndlrDflt SrvPrintfHndlrDflt;

/// Constructor.
/// flags2 - f.e. NPROC_ENPPF_WsaStartup.
NprocServer::NprocServer( const NprocSServer& inp )
	: bWsaCleanup( !!(inp.flags2 & NPROC_ENPPF_WsaStartup) )
	, Success2(0), DataStatPrntFlag(1)
	, Server2(NPROC_EInvalidSocket)
	, ServerNotify(inp.notify2)
	, Inp(new NprocSServer(inp))
	, ServerPortNumber(inp.uServerPort)
	, iCurrCliSck(1848)
{
	Inp->Prntfh = ( Inp->Prntfh ? Inp->Prntfh : &SrvPrintfHndlrDflt );
	Timeout = malloc( sizeof(timeval) );
	//((timeval*)Timeout)->tv_sec = 0;
	//((timeval*)Timeout)->tv_usec = 0;
	static_cast<timeval*>(Timeout)->tv_sec = 0;
	static_cast<timeval*>(Timeout)->tv_usec = 0;
	FdRead = malloc( sizeof(fd_set) );
	if( inp.flags2 & NPROC_ENPPF_WsaStartup ){
#		ifdef WIN32 //{
			WSADATA wsaData;
			int error = WSAStartup( MAKEWORD( 2, 0 ), &wsaData );
			if( error != 0 ){
				//printf( "WSAStartup() failed (1)\n" );
				Inp->Prntfh->NprocSrvPrintf("WSAStartup() failed (1)\n", EVL_LEVEL1 );
				return;
			}
#		endif //}
	}
	static bool bStaticWsaStartupDone = 0;
	if( inp.flags2 & NPROC_ENPPF_StaticWsaStartup && !bStaticWsaStartupDone ){
#		ifdef WIN32 //{
			bStaticWsaStartupDone = 1;
			WSADATA wsaData;
			int error = WSAStartup( MAKEWORD( 2, 0 ), &wsaData );
			if( error != 0 ){
				//printf( "WSAStartup() failed (2)\n" );
				Inp->Prntfh->NprocSrvPrintf("WSAStartup() failed (2)\n", EVL_LEVEL1 );
				return;
			}
#		endif //}
	}
	Success2 = initServer();
}
NprocServer::~NprocServer()
{
	closeAllClientSockets();
	//printf("Server2 data avail: %d,%d", isDataAvailable(Server2), isOOBDataAvailable(Server2) );
	if( Server2 != static_cast<SOCKET2>(NPROC_EInvalidSocket) ){
		close( Server2 ); // close() == closesocket() on MS-WINDOWS
		Server2 = NPROC_EInvalidSocket;
	}
	if(bWsaCleanup){
#		ifdef WIN32 //{
			WSACleanup();
#		endif //}
	}
	free( FdRead );
	free( Timeout );
	delete Inp;
}
bool NprocServer::initServer()
{
	// Server_: Create Socket
	Server2 = socket( AF_INET, SOCK_STREAM, 0 );
	if( Server2 < 0 ){
		Server2 = NPROC_EInvalidSocket;
		//printf("Could not create socket.\n");
		MsgOnCtor = "Could not create socket.";
		Inp->Prntfh->NprocSrvPrintf((MsgOnCtor+"\n").c_str(), EVL_LEVEL1 );
		return 0;
	}
	setNonBlocking( Server2 );

	// Option: SO_REUSEADDR = re-start the program without delay.
	// otherwise if not set, after program exit, while read some data from the client,
	// for aprox 1m, system wont allow creating new server on the
	// same port, bind() will fail.
	// ref: https://stackoverflow.com/questions/548879/releasing-bound-ports-on-process-exit
	int reuse_addr = 1;
	setsockopt( Server2, SOL_SOCKET, SO_REUSEADDR,
		reinterpret_cast<char*>(&reuse_addr), //(char*)&reuse_addr,
		sizeof(reuse_addr) );

	// Starting server.
	struct sockaddr_in sin;
	memset( &sin, 0, sizeof(sin) );

	sin.sin_family      = AF_INET;
	sin.sin_addr.s_addr = INADDR_ANY;
	sin.sin_port        = htons( ServerPortNumber );

	//SOCKET_ERROR ... < 0
	if( bind( Server2, reinterpret_cast<const struct sockaddr*>(&sin), sizeof(sin) ) < 0 ){
		close(Server2);
		Server2 = NPROC_EInvalidSocket;
		MsgOnCtor = "Could not start server. bind() failed.";
		Inp->Prntfh->NprocSrvPrintf((MsgOnCtor+"\n").c_str(), EVL_LEVEL1 );
		return 0;
	}
	while( listen( Server2, SOMAXCONN ) < 0 ); //== SOCKET_ERROR
	return 1;
}
/// Returns true if server has been constructed correctly.
/// I.e. there were no errors durning constructor function.
/// In case of an error, use getMsgOnConstruct() to get textural
/// message associated.
bool NprocServer::isValid()const
{
	return Success2;
}
const char* NprocServer::getMsgOnConstruct()const
{
	return MsgOnCtor.c_str();
}
void NprocServer::setNonBlocking( SOCKET2 s )
{
	unsigned long x = 1;
	//ioctlsocket( s, FIONBIO, &x );
	ioctl( s, FIONBIO, &x ); // ioctl() == ioctlsocket() on MS-Windows
}
void NprocServer::
closesocketLocal2( SOCKET2 s, std::vector<SSocket>::iterator* nextOnEraseOut, int eCbYesNo )
{
	std::vector<SSocket>::iterator a = Clients2.begin();
	if((a=std::find_if(a, Clients2.end(), SSocket::SByCliSck(s))) != Clients2.end()){
		close( a->iCliSck );
		size_t ident = a->uId;
		a = Clients2.erase( a );
		if(nextOnEraseOut)
			*nextOnEraseOut = a;
		if( eCbYesNo == ECS_YES_CALLBACK )
			OnSockedClosed( ident );
	}
	if(DataStatPrntFlag){
		char bfr[256];
		sprintf(bfr,"closed %d client socket, remaining:%d\n",
			static_cast<int>(s), static_cast<int>(Clients2.size()) );
		Inp->Prntfh->NprocSrvPrintf(bfr, EVL_LEVEL3 );
	}
}
void NprocServer::closeAllClientSockets()
{
	while( !Clients2.empty() )
		closesocketLocal2( Clients2.begin()->iCliSck, 0, ECS_NO_CALLBACK );
}

/// member function to be called consecutivelly by the user.
/// Performs all necessary networking send-receive tasks.
bool NprocServer::perform2( bool* bWasIdleOut )
{
	int nReads;
	bool bIdleTmp, success = 1;
	bool& bIdle = bWasIdleOut ? *bWasIdleOut : bIdleTmp;
	bIdle = 1;
	if( Server2 == static_cast<SOCKET2>(NPROC_EInvalidSocket) ){
		char bfr[256];
		sprintf(bfr,"ERROR: server not running.\n" );
		Inp->Prntfh->NprocSrvPrintf(bfr, EVL_LEVEL2 );
		return 0;
	}
	//
	// perform the server socket.
	//
	//((fd_set*)FdRead)->fd_count    = 1;
	//((fd_set*)FdRead)->fd_array[0] = Server2;
	//fd_set* readfds = (fd_set*)FdRead;
	fd_set* readfds = reinterpret_cast<fd_set*>(FdRead);
	FD_ZERO( readfds );
	FD_SET( Server2, readfds );
	// when using "-Os", have this warning:
	// >> warning: call to ‘__fdelt_warn’ declared with attribute warning:
	// >> bit outside of fd_set selected [enabled by default]

	// p1: Server2+1 <-> FD_SETSIZE (as of v1.1)
	nReads = select( Server2+1, readfds, 0, 0, reinterpret_cast<timeval*>(Timeout) );
	if( nReads < 0 ){
		Inp->Prntfh->NprocSrvPrintf("Error, select_() failed (1).\n", EVL_LEVEL1 );
		return 0;
	}
	if( nReads == 0 ){
		// idle
	}else{
		bIdle = 0;
		// check if client is connecting.
		if( FD_ISSET( Server2, reinterpret_cast<fd_set*>(FdRead) ) ){
			SOCKET2 iClientSocket = accept( Server2, 0, 0 );
			if( iClientSocket < 0 ){
				Inp->Prntfh->NprocSrvPrintf("Error, accept() failed.\n", EVL_LEVEL2 );
				return 0;
			}
			setNonBlocking( iClientSocket );
			Clients2.push_back( SSocket( iClientSocket, iCurrCliSck++ ) );
			const SSocket* ssock = &Clients2.back();
			{
				unsigned int len2 = static_cast<unsigned int>(Inp->uSendBufferSize);
				int rsi = setsockopt( iClientSocket, SOL_SOCKET, SO_SNDBUF, reinterpret_cast<char*>(&len2), sizeof(unsigned int) );
				if( rsi ){
					char bfr[256];
					sprintf(bfr,"ERROR: setsockopt() failed (1): %u\n", -1 );//WSAGetLastError()
					Inp->Prntfh->NprocSrvPrintf(bfr, EVL_LEVEL2 );
					closesocketLocal2( iClientSocket, 0, ECS_YES_CALLBACK );
					return 0;
				}
			}
			std::string strIPAddr2, strHostname2;
			sockaddr_in sin;
			int sizename = sizeof(sin);
			memset( &sin, 0, sizeof(sin) );
			//WIN32
			getpeername( iClientSocket, reinterpret_cast<sockaddr*>(&sin),
					reinterpret_cast<socklen_t*>(&sizename) );
			strIPAddr2 = inet_ntoa( sin.sin_addr );
			if( DataStatPrntFlag ){
				char bfr[256];
				sprintf(bfr,"Incomming connection from IP: %s\n", strIPAddr2.substr(0,64).c_str() );
				Inp->Prntfh->NprocSrvPrintf(bfr, EVL_LEVEL3 );
			}
			struct hostent* lphostent = gethostbyaddr( reinterpret_cast<char*>(&sin.sin_addr.s_addr), sizeof(sin.sin_addr.s_addr), AF_INET );
			strHostname2 = lphostent->h_name;

			std::vector<uint8_t> dataarray;
			NprocSClientConnecting ssc;
			ssc.id2         = ssock->uId;
			ssc.strIPAddr   = strIPAddr2;
			ssc.strHostname = strHostname2;
			ssc.port        = ntohs( sin.sin_port );
			ssc.sendBuffer  = &dataarray;
			bool rs = OnClientConnect( ssc );
			if( !dataarray.empty() )
				if( !sendSomeData( iClientSocket, &dataarray[0], dataarray.size() ) )
					success = 0;
			if( !rs )
				closesocketLocal2( iClientSocket, 0, ECS_YES_CALLBACK );
		}
	}
	//
	// perform the client's sockets.
	//
	bool bClientsIdle = 0;
	if( !performClientsSockets( &bClientsIdle ) )
		return 0;
	if( !bClientsIdle )
		bIdle = 0;
	return success;
}
bool NprocServer::performClientsSockets( bool* wasIdleOut )
{
	bool bIdleTmp = 0, success = 1;
	int nReads;
	bool& bIdle = wasIdleOut ? *wasIdleOut : bIdleTmp;
	bIdle = 1;
	std::vector<uint8_t> dataarray;
	if( !Clients2.empty() ){
		std::vector<SSocket>::const_iterator a;
		for( a = Clients2.begin(); a != Clients2.end(); ++a ){
			//((fd_set*)FdRead)->fd_count    = 1;
			//((fd_set*)FdRead)->fd_array[0] = a->iCliSck;
			fd_set* readfds2 = reinterpret_cast<fd_set*>(FdRead);
			FD_ZERO( readfds2 );
			FD_SET( a->iCliSck, readfds2 ); //add master socket to the fd-set.

			// p1: a->iCliSck+1 <-> FD_SETSIZE (as of v1.1)
			nReads = select( a->iCliSck+1, readfds2, 0, 0, reinterpret_cast<timeval*>(Timeout) );
			if( nReads < 0 ){
				Inp->Prntfh->NprocSrvPrintf("ERROR: select_() failed (2)\n", EVL_LEVEL1 );
				return 0;
			}else if( nReads > 0 ){
				bIdle = 0;
				if( FD_ISSET( a->iCliSck, reinterpret_cast<fd_set*>(FdRead) ) ){
					uint8_t recvbuf[256];
					int nTotal = 0, iResult;
					do{
						iResult = recv( a->iCliSck, reinterpret_cast<char*>(recvbuf), sizeof(recvbuf), 0 );
						if( iResult > 0 ){
							if( DataStatPrntFlag ){
								char bfr[256];
								sprintf(bfr,"Bytes received: %d\n", iResult );
								Inp->Prntfh->NprocSrvPrintf(bfr, EVL_LEVEL4 );
							}
							nTotal += iResult;
							dataarray.clear();
							NprocSDataReadFromClient sd;
							sd.id2        = a->uId;
							sd.data       = recvbuf;
							sd.size       = iResult;
							sd.sendBuffer = &dataarray;
							bool rs = OnDataReadFromClient( sd );
							if( !dataarray.empty() ){
								if(!sendSomeData( a->iCliSck, &dataarray[0], dataarray.size() ) )
									success = 0;
							}
							if(!rs)
								closesocketLocal2( a->iCliSck, 0, ECS_YES_CALLBACK );
						}else if( iResult < 0 ){
							char bfr[256];
							sprintf(bfr,"ERROR: recv failed: %d\n", -1 );//WSAGetLastError()
							Inp->Prntfh->NprocSrvPrintf(bfr, EVL_LEVEL2 );
							closesocketLocal2( a->iCliSck, 0, ECS_YES_CALLBACK );
							return 0;
						}
					}while( isDataAvailable(a->iCliSck) );
				}
			}
		}
		if( !(Inp->flags2 & NPROC_ENPPF_NeverSend) && ServerNotify ){
			// check for the sends.
			std::vector<SSocket>::iterator b;
			for( b = Clients2.begin(); b != Clients2.end(); ){
				void* FdWri = FdRead;
				//((fd_set*)FdWri)->fd_count    = 1;
				//((fd_set*)FdWri)->fd_array[0] = b->iCliSck;
				fd_set* wrifds = reinterpret_cast<fd_set*>(FdWri);
				FD_ZERO( wrifds );
				FD_SET( b->iCliSck, wrifds ); //add master socket to the fd-set.
				bool bNeedClose = 0;
				// b->iCliSck+1  <-> FD_SETSIZE (as of v1.1)
				int nWri = select( b->iCliSck+1, 0, wrifds, 0, reinterpret_cast<timeval*>(Timeout) );
				if( nWri < 0 ){
					Inp->Prntfh->NprocSrvPrintf("ERROR: select_() failed (3)\n", EVL_LEVEL1 );
					return 0;
				}else if( nWri > 0 ){
					if( FD_ISSET( b->iCliSck, reinterpret_cast<fd_set*>(FdWri) ) ){
						if(ServerNotify){
							std::vector<uint8_t> dataarr;
							NprocSClientWriteReady sw;
							sw.id2        = b->uId;
							sw.sendBuffer = &dataarr;
							if( !getClientSocketSendSize( b->iCliSck, &sw.uMaxWrite ) ){
								bNeedClose = 1;
							}else{
								bool rs = ServerNotify->nprocOnClientWriteReady( sw );
								if( !sw.sendBuffer->empty() ){
									if( !sendSomeData( b->iCliSck, &dataarr[0], dataarr.size(), ESSDF_DontCloseOnError ) )
										bNeedClose = 1;
								}
								if(!rs)
									bNeedClose = 1;
							}
						}
					}
				}
				if(bNeedClose){
					closesocketLocal2( b->iCliSck, &b, ECS_YES_CALLBACK );
				}else
					++b;
			}
		}
		// check sockets for the read-data available.
		{
			std::vector<SSocket>::iterator a;
			for( a = Clients2.begin(); a != Clients2.end(); ){
				if( !isDataAvailable(a->iCliSck) || !isOOBDataAvailable(a->iCliSck) ){
					dataarray.clear();
					bool bFailed = 0;
					NprocSClientIdleNoMoreData snd;
					snd.id2        = a->uId;
					snd.sendBuffer = &dataarray;
					bool rs = OnClientIdleOrNoMoreData( snd );
					if( !dataarray.empty() ){
						bIdle = 0;
						if( !sendSomeData( a->iCliSck, &dataarray[0], dataarray.size(), ESSDF_DontCloseOnError ) ){
							success = 0;
							bFailed = 1;
						}
					}
					if( !rs || bFailed ){
						closesocketLocal2( a->iCliSck, &a, ECS_YES_CALLBACK );
					}else{
						++a;
					}
				}else{
					++a;
				}
			}
		}
	}
	return success;
}
// flagsx - i.e. ESSDF_DontCloseOnError.
bool NprocServer::sendSomeData( SOCKET2 s, const uint8_t* data, size_t size, size_t flagsx )
{
	int iSendResult;
	char* data3 = reinterpret_cast<char*>( const_cast<uint8_t*>(data) );
	iSendResult = send( s, data3, size, 0 );
	if( iSendResult < 0 ){ //== SOCKET_ERROR
		char bfr[256];
		sprintf(bfr,"ERROR: send() failed. Code: %d, data-size: %d\n", iSendResult, static_cast<int>(size) );
		Inp->Prntfh->NprocSrvPrintf(bfr, EVL_LEVEL2 );
		if( !(flagsx & ESSDF_DontCloseOnError) )
			closesocketLocal2( s, 0, ECS_YES_CALLBACK );
		return 0;
	}
	//printf_("Bytes sent: %d\n", iSendResult );
	return 1;
}
bool NprocServer::OnClientConnect( const NprocSClientConnecting& inp )
{
	if(ServerNotify)
		return ServerNotify->nprocOnClientConnect( inp );
	return 1;
}
bool NprocServer::OnDataReadFromClient( const NprocSDataReadFromClient& inp )
{
	if(ServerNotify)
		return ServerNotify->nprocOnDataReadFromClient( inp );
	return 1;
}
bool NprocServer::OnClientIdleOrNoMoreData( const NprocSClientIdleNoMoreData& inp )
{
	if(ServerNotify)
		return ServerNotify->nprocOnClientIdleOrNoMoreData( inp );
	return 0;
}
bool NprocServer::isDataAvailable( SOCKET2 s )
{
	unsigned long res = 0;
	ioctl( s, FIONREAD, &res );
	return !!res;
}
bool NprocServer::isOOBDataAvailable( SOCKET2 s )
{
	unsigned long res = 0;
	ioctl( s, SIOCATMARK, &res );
	return !res;
}
void NprocServer::OnSockedClosed( size_t id )
{
	ServerNotify->nprocOnConnectionClosed( id );
}
bool NprocServer::getClientSocketSendSize( SOCKET2 s, size_t* sizeOut )
{
	*sizeOut = 0;
	int len = 0; int tmp2 = sizeof(int); //SO_MAX_MSG_SIZE
	//WIN32
	int rsi = getsockopt( s, SOL_SOCKET, SO_SNDBUF,
				reinterpret_cast<char*>(&len), reinterpret_cast<socklen_t*>(&tmp2) );
	if( rsi ){
		char bfr[256];
		sprintf(bfr,"ERROR: getsockopt() failed (1), code:%d\n", rsi );
		Inp->Prntfh->NprocSrvPrintf(bfr, EVL_LEVEL2 );
		return 0;
	}
	*sizeOut = ( len > 0 ? static_cast<size_t>(len) : 0 );
	return 1;
}
/// Used to close particular connection manually (available for the user).
/// \param id2 - connection identifier, same that is passed in the nproc-callbacks
///              (f.e. NprocSClientConnecting::id2).
/// \param flags3 - flags, f.e. NPROC_ECCF_NoNotifyCallback.
bool NprocServer::closeConnection( size_t id2, size_t flags3 )
{
	std::vector<SSocket>::iterator a = Clients2.begin();
	if((a=std::find_if(a, Clients2.end(), SSocket::SByUID(id2))) != Clients2.end() ){
		closesocketLocal2( a->iCliSck, 0,
			flags3 & NPROC_ECCF_NoNotifyCallback ? ECS_NO_CALLBACK : ECS_YES_CALLBACK );
		return 1;
	}
	return 0;
}

} // end namespace mproc
