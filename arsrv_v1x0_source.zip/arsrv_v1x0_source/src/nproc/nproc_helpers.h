
#ifndef _NPROC_HELPERS_H_
#define _NPROC_HELPERS_H_
#include <string>
#include <vector>
#include <stdint.h>
namespace nproc {

enum {
	/// Initial value for invalid socket.
	NPROC_EInvalidSocket = -1,
};
std::string          nproc_CreateSimpleHttpRqHeader( const char* szHost, const char* szRq, const char* szOffset = "", const char* method = "" );
std::vector<uint8_t> nproc_StrToBytes( const char* in );
std::string          nproc_dataToString( const void* data, size_t size, size_t flags = 0 );
bool                 nproc_decodeHttpRangeHeader( const char* szRangeHdr, std::string* pos = 0, std::pair<bool,std::string>* rangeEnd = 0 );
void                 nproc_Sleep( uint32_t nMilisecs );
std::vector<uint8_t> nproc_CreateSimpleHTTPOKResponse( const char* szBody = "OK" );
std::vector<uint8_t> nproc_CreateSimpleHTTPNotFoundResponse( const char* szBody = "", const char* szCustHdrs = "" );

enum{
	NPROC_EDTS_ShowCrLfAsStrs = 0x1,
	NPROC_EDTS_LfFollowsVisibleLf = 0x2,	//only relevant if used with NPROC_EDTS_ShowCrLfAsStrs.
};

} // end namespace nproc

#endif //_NPROC_HELPERS_H_
