
#ifndef _C_NTW_SERVER_H_
#define _C_NTW_SERVER_H_
#include <vector>
#include <string>
#include <stdint.h>
#include "nproc_helpers.h"

namespace nproc {

class NprocISrvOnClientNotify; struct NprocSClientConnecting;
struct NprocSDataReadFromClient; struct NprocSClientIdleNoMoreData;
struct NprocSServer;
struct NprocSClientWriteReady; class NprocISrvPrintfHandler;

enum { NPROC_ECCF_NoNotifyCallback = 0x1, };

/**
	Class for creating server that accepts connection and provides means for
	sending and receiving data.
	Itself not a multithreded class, user code is intended to make consecutive
	calls tp NprocServer::perform2(), a member function that, once
	the object initialized, is performing all
	necessary operations, notably interacting with the clients.
	For notification callbacks, see description of NprocISrvOnClientNotify
	member methods.

	Examples:
	\code
		class CNsInterface : public NprocISrvOnClientNotify {
		public:
			//...
		} NsInterface ;
		//...
		NprocSServer sns;
		sns.notify2     = &NsInterface;
		///...
		NprocServer srv( sns );
		//...
	\endcode
*/
class NprocServer //CNtwServer_
{
	typedef size_t SOCKET2;
	struct SSocket;
public:
	//enum { NPROC_ECCF_NoNotifyCallback = 0x1, };
	;            NprocServer( const NprocSServer& );
	virtual      ~NprocServer();
	virtual bool perform2( bool* bWasIdleOut=0 );
	void         setDataStatusPrint( bool in_ ) {DataStatPrntFlag = in_;}
	bool         isValid()const;
	const char*  getMsgOnConstruct()const;
	void         setNotifyIntrf( NprocISrvOnClientNotify* in_ ) {ServerNotify = in_;}
	bool         closeConnection( size_t id_, size_t flags_ = 0 );
private:
	static void setNonBlocking( SOCKET2 s );
	bool initServer();
	void closeAllClientSockets();
	void closesocketLocal2( SOCKET2, std::vector<SSocket>::iterator* nextOnEraseOut, int eCbYesNo );
	bool performClientsSockets( bool* wasIdleOut );
	enum { ESSDF_DontCloseOnError = 0x1, };
	bool sendSomeData( SOCKET2 s, const uint8_t* data, size_t size, size_t flagsx = 0 );
	bool isDataAvailable( SOCKET2 s );
	bool isOOBDataAvailable( SOCKET2 s );
	//
	bool OnClientConnect( const NprocSClientConnecting& inp );
	bool OnDataReadFromClient( const NprocSDataReadFromClient& inp );
	bool OnClientIdleOrNoMoreData( const NprocSClientIdleNoMoreData& inp );
	void OnSockedClosed( size_t id_ );
	bool getClientSocketSendSize( SOCKET2 s, size_t* sizeOut );
private:
	enum ECloseSocket {
		ECS_YES_CALLBACK,
		ECS_NO_CALLBACK,
	};
	enum {
		EVL_LEVEL1 = 1,
		EVL_LEVEL2 = 2,
		EVL_LEVEL3 = 3,
		EVL_LEVEL4 = 4,
	};
	struct SSocket {
		SOCKET2  iCliSck;
		size_t   uId;
		SSocket( SOCKET2 iCliSck_, size_t uId_ ) : iCliSck(iCliSck_), uId(uId_) {}
		struct SByUID {
			SByUID( size_t uConnID_ ) : uConnID(uConnID_) {}
			bool operator()( const SSocket& in_ )const {return in_.uId == uConnID;}
			size_t uConnID;
		};
		struct SByCliSck {
			SByCliSck( SOCKET2 idSck_ ) : idSck(idSck_) {}
			bool operator()( const SSocket& in_ )const {return in_.iCliSck == idSck;}
			SOCKET2 idSck;
		};
	};
	bool                        bWsaCleanup, Success2, DataStatPrntFlag;
	SOCKET2                     Server2;
	NprocISrvOnClientNotify*    ServerNotify;
	NprocSServer*               Inp;
	size_t                      ServerPortNumber, iCurrCliSck;
	std::vector<SSocket>        Clients2;
	void*                       FdRead, *Timeout;
	std::string                 MsgOnCtor;
};
struct NprocSClientConnecting {
	size_t                id2;         ///< Connection identifier. Note, assigned by base class, user should store this value and use it to identify further callbacks.
	std::string           strIPAddr;   ///< IP address string, f.e. "127.0.0.1".
	std::string           strHostname; ///< Resolved host name string, f.e. "localhost".
	size_t                port;        ///< Mostly irrelevant, remote port number, the number client choses on it's connection side.
	std::vector<uint8_t>* sendBuffer;  ///< Bytes added to this buffer will be send immediatelly after calback method returns.
	NprocSClientConnecting() : id2(-1), port(0), sendBuffer(0) {}
};
struct NprocSDataReadFromClient {
	size_t                id2;
	const uint8_t*        data;
	size_t                size;
	std::vector<uint8_t>* sendBuffer;
};
struct NprocSClientIdleNoMoreData {
	size_t                id2;
	std::vector<uint8_t>* sendBuffer;
	NprocSClientIdleNoMoreData() : id2(0) {}
};
/// The Notify interface for NprocServer class.
/// The term 'user', used below, refers to derived class or to code that implements
/// virtual functions.
class NprocISrvOnClientNotify {
public:
	/// Called when some client connects to the server.
	/// Return false to close the connection immediatelly.
	/// Default method accepts all connections.
	virtual bool nprocOnClientConnect( const NprocSClientConnecting& in_ ){
		return 1;
	}
	/// Caled when some data has been read for the corresponding connection.
	/// Return false to close the connection.
	virtual bool nprocOnDataReadFromClient( const NprocSDataReadFromClient& in_ ){
		return 1;
	}
	/// Called when there is no more data available or this client became idle.
	/// Default function returns zero causing connection to close immediatelly.
	/// User may however chose to wait before closing.
	/// If user choses not to close connection, successive calls to
	/// this method will follow, user may calculate time elapsed and chose to
	/// close the connection after more time passes.
	/// NOTE: while waiting, client may send more data via nprocOnDataReadFromClient().
	/// After returning zero there will be no more idle notifications and
	/// connection will close automatically.
	virtual bool nprocOnClientIdleOrNoMoreData( const NprocSClientIdleNoMoreData& in_ ){
		return 0;
	}
	/// Called when client is ready to recieve data.
	/// Maximum data added to output array must not exceed size set in 'inp.uMaxWrite'.
	virtual bool nprocOnClientWriteReady( const NprocSClientWriteReady& inp ){
		return 1;
	}
	/// Called when connection has been closed.
	/// User will know if connection has been closed prematurelly by noticing that
	/// this method has been called before user closing connection by returning 0 via other
	/// callbeack methods.
	virtual void nprocOnConnectionClosed( size_t id_ ){
	}
};
/// Init structire for NprocServer.
struct NprocSServer {
	size_t                      flags2;			/// Flags, f.e. NPROC_ENPPF_WsaStartup.
	size_t                      uServerPort;
	NprocISrvOnClientNotify*    notify2;
	size_t                      uSendBufferSize;
	NprocISrvPrintfHandler*     Prntfh;
	NprocSServer() : flags2(0), uServerPort(8080), notify2(0), uSendBufferSize(65536), Prntfh(0) {}
};
struct NprocSClientWriteReady {
	size_t id2;
	size_t uMaxWrite;
	std::vector<uint8_t>* sendBuffer;
	NprocSClientWriteReady() : id2(0), uMaxWrite(0), sendBuffer(0) {}
};
enum{
	// performs WSA startup.
	NPROC_ENPPF_WsaStartup = 0x1,
	// performs WSA startup and ensures its done one time in process instance.
	// cannot be combined with NPROC_ENPPF_WsaStartup.
	NPROC_ENPPF_StaticWsaStartup = 0x2,
	// WIP. if set server will never check for sends durning perform method.
	NPROC_ENPPF_NeverSend = 0x4,
};
class NprocISrvPrintfHandler {
public:
	virtual void NprocSrvPrintf( const char* inp, size_t uVerbLevel ) = 0;
};

} // end namespace mproc

#endif //_C_NTW_SERVER_H_
