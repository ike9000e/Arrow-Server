#!/bin/bash
#
bdir="$(dirname "$(readlink -f "$0")")"


	export LD_PRELOAD=$bdir/../bin/release/xwmodutil.so
	# :nSearchWndAfter=1000
	# :nUseMapFromTo=0,4
	# :szActiveIf=
	export XWMODUTIL_CFG="bOnFirstInput=1:swi2=$bdir/xwmu_icn2.pam"

	# pcmanfm
	# gpicview
	leafpad
	